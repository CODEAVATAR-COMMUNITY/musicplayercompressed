package com.example.android.udacitymusicplayer;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

public class MusicPlayer extends AppCompatActivity {
    SeekBar seekbar;
    ImageButton imagebutton;
    ImageButton imagebutton2;
    ImageButton imagebutton3;
    Handler handler;
    int progress = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.musicplayer);
        seekbar = findViewById(R.id.seekBar);
        imagebutton = findViewById(R.id.imageButton);
        imagebutton2 = findViewById(R.id.imageButton2);
        imagebutton3 = findViewById(R.id.imageButton3);
        Intent mpintent = getIntent();
        if (mpintent != null) {
            int mpimageid = mpintent.getIntExtra("SongImage", R.drawable.songimage1);
            String mpsongname = mpintent.getStringExtra("SongName");
            ImageView mpimageview = findViewById(R.id.imageView);
            TextView mptextview = findViewById(R.id.textView);
            mpimageview.setImageResource(mpimageid);
            mptextview.setText(mpsongname);
        }
        imagebutton3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent songintent = new Intent(MusicPlayer.this, SongsList.class);
                startActivity(songintent);
            }
        });
        handler = new Handler();
        seekbarchange();
    }
    private void seekbarchange() {
        seekbar.setProgress(progress);
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                seekbarchange();
            }
        };
        handler.postDelayed(runnable, 1000);
        progress = progress + 1;
    }
}