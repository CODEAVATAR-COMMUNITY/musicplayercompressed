package com.example.android.udacitymusicplayer;
class Song {
    int imageid;
    String songname;
    Song(int imageid, String songname) {
        this.imageid = imageid;
        this.songname = songname;
    }
    public String nameofsong() {
        return songname;
    }
    public int imageofsong() {
        return imageid;
    }
}
